﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E_Library;
namespace EMPDATA
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Employees EMP = new Employees(12, "Megha", 7000);
            Console.WriteLine("Employee ID is ==>" + EMP.EmpID);
            Console.WriteLine("Employee Name is ==>" + EMP.Ename);
            Console.WriteLine("Employee Salary is --->" + EMP.EmpSalary);
            EMP.CalculateSalary();
            Console.ReadKey();
        }
    }
}
