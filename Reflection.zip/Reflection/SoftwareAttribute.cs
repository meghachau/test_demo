﻿using System;
using System.Reflection;
namespace Inheritance_and_Polymorphism
{

    [AttributeUsage(AttributeTargets.All)]
	public class MyAttribute : Attribute
	{

		// Provides name of the member
		private string name;

		// Provides description of the member
		private string action;

		// Constructor
		public MyAttribute(string name, string action)
		{
			this.name = name;
			this.action = action;
		}

		// property to get name
		public string Name
		{
			get { return name; }
		}

		// property to get description
		public string Action
		{
			get { return action; }
		}
	}
	class HDFCAccount
	{
		private string projectName;
		private string discription;
		private string clientName;
		private string startDate;
		private string endDate;

		[MyAttribute("Modifier", "Assigns the Student Details")]
		public void setDetails(string PName,string Pdiscription,string CName,string Sdate,string endedate)
		{
			projectName = PName;
			discription = Pdiscription;
			clientName = CName;
			startDate = Sdate;
			endDate = endedate;
		}

		[MyAttribute("Accessor", "Returns Value of Project Name")]
		public string getprojectName()
		{
			return projectName;
		}
		[MyAttribute("Accessor", "Returns Value of Project discription")]
		public string getdiscription()
		{
			return discription;
		}
		[MyAttribute("Accessor", "Returns Value of Client value")]
		public string getclientName()
		{
			return clientName;
		}
		[MyAttribute("Accessor", "Returns Value of starting date")]
		public string getstartDate()
		{
			return startDate;
		}

		[MyAttribute("Accessor", "Returns Value of end date")]
		public string getendDate()
		{
			return endDate;
		}

	}
	class SoftwareAttribute
    {
		public static void Main()
		{
			Type T = Type.GetType("Inheritance_and_Polymorphism.Customer");
			Console.WriteLine("----------------properties in class------------------");
			PropertyInfo[] properties = T.GetProperties();
			foreach (PropertyInfo property in properties)
			{
				Console.WriteLine(property.Name);
			}
			Console.WriteLine("Methods in class..");
			MethodInfo[] Methods = T.GetMethods();
			foreach (MethodInfo Method in Methods)
			{
				Console.WriteLine(Method.Name);
			}


			Console.WriteLine("------------------Project details using attribute--------------------------");
			HDFCAccount P = new HDFCAccount();
			P.setDetails("Bank Project","IT based","HDFC","17-04-22","18-04-22");
			Console.WriteLine("Project Details....");
			Console.WriteLine("Project Name"          + P.getprojectName());
			Console.WriteLine("Project Discribtion"   + P.getdiscription());
			Console.WriteLine("Project ClientName"    +P.getclientName());
			Console.WriteLine("Project Start Date"    + P.getstartDate());
			Console.WriteLine("Project End Date"      + P.getendDate());

			Console.ReadKey();

		}
    }

}
