﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Inheritance_and_Polymorphism
{

    public class Customer
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public Customer()
        {
            this.ID = -1;
            this.Name = string.Empty;
        }
        public Customer(int id, string name)
        {
            this.ID = id;
            this.Name = name;
        }
        public void PrintID()
        {

            Console.WriteLine("Id is..{0}", this.ID);
        }
        public void PrintName()
        {

            Console.WriteLine("Name is..{0}", this.Name);
        }
    }

    class RefelctionExample
    {
        public static void Main()
        {
        Type T = Type.GetType("Inheritance_and_Polymorphism.Customer");
            Console.WriteLine("properties in class");
            PropertyInfo[] properties = T.GetProperties();
            foreach (PropertyInfo property in properties)
            {
                Console.WriteLine(property.Name);
            }
            Console.WriteLine("Methods in class..");
            MethodInfo[] Methods = T.GetMethods();
            foreach (MethodInfo Method in Methods)
            {
                Console.WriteLine(Method.Name);
            }

            Console.ReadKey();
        }
        
    }
}
