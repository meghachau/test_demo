﻿using SerializedEmpManager;
using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
namespace EMPManagerSerilized
{
    class Program
    {
        static void Main(string[] args)
        {
            EMP E = new EMP(12, "Megha", 7000);
            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream(@"D:\C#\Object Oriented Programming\EMPserizationFile.txt", FileMode.Create, FileAccess.Write);


            formatter.Serialize(stream, E);
            stream.Close();

            stream = new FileStream(@"D:\C#\Object Oriented Programming\EMPserizationFile.txt", FileMode.Open, FileAccess.Read);
            EMP objnew = (EMP)formatter.Deserialize(stream);

            
            objnew.CalculateSalary();
            Console.ReadKey();
            Console.ReadKey();


        }
    }
}
