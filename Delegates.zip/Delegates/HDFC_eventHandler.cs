﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_and_Polymorphism
{
    class HDFC_eventHandler
    {

        public delegate void HDFCAccount(int x);
        class EventProgram
        {
            public int accountnumber { get; set; }
            public string customername { get; set; }
            public decimal customerbalance = 1500;
            public decimal FixAmount = 1000;
            event HDFCAccount underbalance;
            event HDFCAccount zerobalance;

            public void Insufficient(int WithdrawnAmount)
            {
                underbalance(WithdrawnAmount);

            }
            public void depositeamount(int depositeamount)
            {
                zerobalance(depositeamount);
            }
            public void withdrawamount(int WithdrawnAmount)
            {
                if (WithdrawnAmount < customerbalance && customerbalance != 0)
                {
                    decimal remainingBalanced = customerbalance - WithdrawnAmount;
                    Console.WriteLine("Remaining balanced is:" + (customerbalance - WithdrawnAmount));

                    if (remainingBalanced < FixAmount)
                    {
                        Console.WriteLine("Transaction cant be continued to spcified limit of RS.1000...");
                    }
                    else 
                    {
                        Console.WriteLine("Transaction Successful...");
                    }
                }
                else if (WithdrawnAmount > customerbalance && customerbalance != 0)
                {
                    Console.WriteLine("Insuffient balanced....");
                }
                else
                {
                    Console.WriteLine("Zero balance", customerbalance);
                }

            }

            public void Depositeamount(int depositeamount)
            {
                Console.WriteLine("Balance after depositing" + (customerbalance) + depositeamount);

            }
            public static void Main()
            {
                EventProgram EP = new EventProgram();
                Console.WriteLine("Enter want you want to do.Withdrawn Amount or Deposite :w or d");
                string choice = Console.ReadLine();
                if (choice == "w")
                {
                    Console.WriteLine("Enter the amount to withdrawn...");
                    int Withdrawn_amount = Convert.ToInt32(Console.ReadLine());
                    EP.underbalance += new HDFCAccount(EP.withdrawamount);
                    EP.Insufficient(Withdrawn_amount);
                }
                else
                {
                    Console.Write("Enter the amount to Deposite...");
                    int Deposite_amount = Convert.ToInt32(Console.ReadLine());
                    EP.zerobalance += new HDFCAccount(EP.Depositeamount);
                    EP.Depositeamount(Deposite_amount);
                }
                Console.ReadKey();
            }

        }

    }
}
