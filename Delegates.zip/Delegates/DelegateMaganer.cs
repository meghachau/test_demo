﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_and_Polymorphism
{
    public  delegate void EmployeeDelegate();
    class Employee
    {

        private double HRA;
        private double TA;
        private double DA;
        private double PF;
        private double TDS;
        private double NetSalary;
        private double GrossSalary;

        public int EmpID
        {

            get; set;
        }
        public string Ename { get; set; }
        public double EmpSalary { get; set; }

        public Employee(int empID, string EmpName, double Esalary)
        {
            this.EmpID = empID;
            this.Ename = EmpName;
            this.EmpSalary = Esalary;

            if (Esalary < 5000)
            {
                HRA = (Esalary * 10) / 100;
                TA = (Esalary * 5) / 100;
                DA = (Esalary * 15) / 100;
            }
            else if (Esalary < 10000)
            {
                HRA = (Esalary * 15) / 100;
                TA = (Esalary * 10) / 100;
                DA = (Esalary * 20) / 100;

            }
            else if (Esalary < 15000)
            {
                HRA = (Esalary * 20) / 100;
                TA = (Esalary * 15) / 100;
                DA = (Esalary * 25) / 100;
            }
            else if (Esalary < 20000)
            {
                HRA = (Esalary * 25) / 100;
                TA = (Esalary * 20) / 100;
                DA = (Esalary * 30) / 100;
            }
            else
            {
                HRA = (Esalary * 30) / 100;
                TA = (Esalary * 25) / 100;
                DA = (Esalary * 35) / 100;
            }
            GrossSalary = Esalary + HRA + TA + DA;
            //Console.WriteLine("Gross Salary of this Employee -->" + GrossSalary);
        }
        public void PrintEmpInfo()
        {
            Console.WriteLine("Employee ID is ==>" + EmpID);
            Console.WriteLine("Employee Name is ==>" + Ename);
            Console.WriteLine("Employee Salary is --->" + EmpSalary);
        }
        public void CalculateSalary()
        {
            PF = (GrossSalary * 10) / 100;
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);
            
            Console.WriteLine("Gross Salary of this Employee -->" + GrossSalary);
            Console.WriteLine("Net Salary of Employee --->" + NetSalary);
        }
    }
    
    class DelegateMaganer
    {

        static void Main(string[] args)
        {

            Employee Emp = new Employee(2, "Mark", 7000);
            EmployeeDelegate DEMP = new EmployeeDelegate(Emp.PrintEmpInfo);
            EmployeeDelegate DEMP1 = new EmployeeDelegate(Emp.CalculateSalary);
            // Emp.CalculateSalary();
            DEMP();
            DEMP1();
            Console.ReadKey();

        }
    }
}
