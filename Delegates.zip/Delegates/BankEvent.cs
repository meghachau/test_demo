﻿using System;

namespace Inheritance_and_Polymorphism
{
    class BankEvent
    {
        public delegate void account(int x);

        public class Account
        {
            public int accountNumber { get; set; }
            public string  CustomerName { get; set; }
            public decimal balance = 1500;

            public event account Underbalance;
            public event account Zerobalance;

            public void insufficient(int x)
            {
                Underbalance(x);
             
            }
            public void DepositeAmount(int y)
            {
                Zerobalance(y);
            }
            public void Withdraw(int x)
            {
                if (x < balance && balance != 0)
                {
                    Console.WriteLine("Transaction Successful...");
                }
                else if (x > balance && balance != 0)
                {
                    Console.WriteLine("Insufficient Amount...");
                }
                else 
                {
                    Console.WriteLine("Zero balance", balance);
                }
            
            }
            public void deposite(int x)
            {
                Console.WriteLine("Balance after depositing"+(balance)+x);
            
            }



        }
        public static void Main()
        {
            Account A = new Account();
            Console.WriteLine("Enter want you want to do.Withdrawn Amount or Deposite :w or d");
            string choice = Console.ReadLine();
            if (choice == "w")
            {
                Console.WriteLine("Enter the amount to withdrawn...");
                int Withdrawn_amount = Convert.ToInt32(Console.ReadLine());
                A.Underbalance += new account(A.Withdraw);
                A.insufficient(Withdrawn_amount);
            }
            else 
            {
                Console.Write("Enter the amount to Deposite...");
                int Deposite_amount = Convert.ToInt32(Console.ReadLine());
                A.Zerobalance += new account(A.deposite);
                A.deposite(Deposite_amount);
            }
            Console.ReadKey();
        }
    }
}
