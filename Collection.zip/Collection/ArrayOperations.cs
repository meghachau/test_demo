﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_and_Polymorphism
{
    public class Oprations
    {
        public void PrintArray(int[] array)
        {
            Console.WriteLine("Elemetns of array are...");
            for (int i = 0; i < array.Length; i++)
            {
                 Console.WriteLine(array[i]);
            }
        }
        public void sortArray(int []array)
        {
            Array.Sort(array);
            Console.WriteLine("Array elements after Sorting......");
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }
        }
        public void ReverseArray(int []array)
        {
            Array.Reverse(array);
            Console.WriteLine("Rverse Array is....");
             for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }
        }
        public void ClearArray(int[] array)
        {
            Array.Clear(array, 0, array.Length);
            Console.WriteLine("Array after clear Opration...");
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }
        }

        public void copyArray(int[] array)
        {
            int[] target = new int[5];
            Array.Copy(array, target, 5);
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(target[i]);
            }

        }
    }
    class ArrayOperations
    {
        public static void Main()
        {
            Oprations op = new Oprations();
            int[] array = new int[5];
            //int choice;
            Console.WriteLine("Enter the array elements...");
            for (int i = 0; i < array.Length; i++)
            {

                array[i] = Convert.ToInt32(Console.ReadLine());
            }
            while (true)
            {
                //Console.WriteLine("Enter your choice");
                //int choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("1. Display the Array");
                Console.WriteLine("2. Sort Array Elements");
                Console.WriteLine("3.Reverse Array Elements");
                Console.WriteLine("4.Copy Array Elements");
                Console.WriteLine("5.Clear Array Elements");
                Console.WriteLine("Enter your choice");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        op.PrintArray(array);
                        
                        break;
                    case 2:
                        op.sortArray(array);
                        break;
                    case 3:
                        op.ReverseArray(array);
                        break;
                    case 4:
                        op.copyArray(array);
                        break;
                    case 5:
                        op.ClearArray(array);
                        break;
                }
                Console.ReadKey();
            }
        }
            
           
    }
}
