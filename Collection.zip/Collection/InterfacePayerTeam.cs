﻿using System;
using System.Collections;

namespace Inheritance_and_Polymorphism
{
    class Player : IEnumerable
    {
        Player[] Items = null;
        int freeIndex = 0;
        public String PlyerName { get; set; }
        public int Score { get; set; }
        public Player()
        {
            Items = new Player[10];
        }
        public void Add(Player item)
        {
            Items[freeIndex] = item;
            freeIndex++;
        }
        // IEnumerable Member  
        public IEnumerator GetEnumerator()
        {
            foreach (object o in Items)
            {
                if (o == null)
                {
                    break;
                }
                yield return o;
            }
        }
    }


    class InterfacePayerTeam
    {
        public static void Main(String[] args)
        {
            Player India = new Player();
           
            India.PlyerName = "Dhoni";
            India.Score = 75;
            Player t2 = new Player();
            t2.PlyerName = "Virat";
            t2.Score = 65;
            Player myList = new Player();
            myList.Add(India);
            myList.Add(t2);
            foreach (Player obj in myList)
            {
                Console.WriteLine("Name:- " + obj.PlyerName +"  "+ "Score :- " + obj.Score);
            }
            Console.ReadLine();
        }
    }
}
