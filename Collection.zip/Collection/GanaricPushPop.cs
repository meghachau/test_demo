﻿using System;
using System.Collections;
namespace Inheritance_and_Polymorphism
{
    class Stack
    {
        private int[] elements;
        private int top;
        private int max;

        public Stack(int size)
        {
            elements = new int[size];
            top = -1;
            max = size;
        }
        public void push(int item)
        {
            if (top == max - 1)
            {
                throw new Exception("Stack Overflow....");
            }
            else
            {
                elements[++top] = item;
            }
        }
        public int pop()
        {
            if (top == -1)
            {
                throw new Exception("Stack is Empty");
            }
            else
            {
                Console.WriteLine("POPed element is" + elements[top]);
                return elements[top--];
            }
        }
        public void printStack()
        {
            if (top == -1)
            {
                Console.WriteLine("Satck is Empty...");
                return;
            }
            else
            {
                for (int i = 0; i <= top; i++)
                {
                    Console.WriteLine("Item[" + (i + 1) + "):" + elements[i]);
                }
            }
        }

    }
    class GanaricPushPop
    {
        public static void Main()
        {
            Stack S = new Stack(5);
            ArrayList e1 = new ArrayList();
            e1.Add(10);
            e1.Add(20);
            e1.Add(30);
            e1.Add(40);
            e1.Add(50);

            foreach (int y in e1)
            {
                //Console.WriteLine("The list item: " + y);
                S.push(y);
                S.printStack();
                S.pop();
                
            }
            Console.ReadKey();
        }
    }
}
