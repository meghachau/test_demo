﻿using System;
using System.Collections.Generic;

namespace Inheritance_and_Polymorphism
{

    class EMP_details
    {
        public static int count = 0;

        // public int EMPID { get; set; }
        public string EMPName { get; set; }
       // public double EMPSalary { get; set; }

    }

    class EmploeeLinklist
    {
        public static void Main()
        {
            LinkedList<string> linked = new LinkedList<string>();
            linked.AddLast("RAM");
            linked.AddLast("SAM");
            linked.AddLast("John");
            linked.AddFirst("Jose");
            //
            // Loop through the linked list with the foreach-loop.
            //
            foreach (var item in linked)
            {
                Console.WriteLine(item);
            }
        }
    
    }

}
