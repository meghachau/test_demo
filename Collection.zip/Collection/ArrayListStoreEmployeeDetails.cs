﻿using System;
using System.Collections;

namespace Inheritance_and_Polymorphism
{
    class EmployeeDetails
    {
        
       // public static int count = 0;


        public int EMPID { get; set; }
        public string  EMPName { get; set; }
        public double EMPSalary { get; set; }

       /* public EmployeeDetails(int id,string name,double  salary)
        {
            this.EMPID = id;
            this.EMPName = name;
            this.EMPSalary = salary;
            count++;
        }*/
    }

    class ArrayListStoreEmployeeDetails
    {
        public static void Main()
        {
            
            
            ArrayList e1 = new ArrayList()
            {
                new EmployeeDetails{EMPID=10,EMPName="Megha",EMPSalary=1000},
                new EmployeeDetails{EMPID=20,EMPName="Megha1",EMPSalary=11000},
                new EmployeeDetails{EMPID=30,EMPName="Megha2",EMPSalary=41000},

             };
            foreach (EmployeeDetails i in e1)
            {
                Console.WriteLine("ID-->"+" "+i.EMPID +" "+ "Name-->"+ " "+  i.EMPName+" " +"Salary-->"+" "+i.EMPSalary);
            }

            Console.ReadKey();


        }
    }
}
