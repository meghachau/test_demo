﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assinement1
{
    class AvarageMarks
    {
        public static void Main()
        {
            int max;
            Console.WriteLine("Enter the Avarage marks of 1 student--->");
            int stud1_marks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Avarage marks of 2 student--->");
            int stud2_marks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Avarage marks of 3 student--->");
            int stud3_marks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Avarage marks of 4 student--->");
            int stud4_marks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Avarage marks of 5 student--->");
            int stud5_marks = Convert.ToInt32(Console.ReadLine());

            if (stud1_marks > stud2_marks && stud1_marks > stud3_marks && stud1_marks > stud4_marks && stud1_marks > stud5_marks)
            {
                max = stud1_marks;
            }
            else if (stud2_marks > stud1_marks && stud2_marks > stud3_marks && stud2_marks > stud4_marks && stud2_marks > stud5_marks)
            {
                max = stud2_marks;
            }
            else if (stud3_marks > stud1_marks && stud3_marks > stud2_marks && stud3_marks > stud4_marks && stud3_marks > stud5_marks)
            {
                max = stud3_marks;
            }
            else if (stud4_marks > stud1_marks && stud4_marks > stud2_marks && stud4_marks > stud3_marks && stud4_marks > stud5_marks)
            {
                max = stud4_marks;
            }
            else 
            {
                max = stud5_marks;
            }
            Console.WriteLine("Highest Avarge marks from 5 student is " + max);
            Console.ReadKey();
        }

    }
}
