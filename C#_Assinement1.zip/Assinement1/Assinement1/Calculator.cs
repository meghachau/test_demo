﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assinement1
{
    class Calculator
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*************Calulator******************");
            Console.WriteLine(" \n");
            
                Console.WriteLine("1. Addtion ");
                Console.WriteLine("2. Subtraction ");
                Console.WriteLine("3. Multiplication ");
                Console.WriteLine("4. Division ");
                Console.WriteLine("Enter your choice---->");



                int a, b, result;
                int ch = Int32.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter the value of A --->");
                        a = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter the value of B --->");
                        b = Convert.ToInt32(Console.ReadLine());
                        result = a + b;
                        Console.WriteLine("Addtion of A and B --->" + result);
                        break;
                    case 2:
                        Console.WriteLine("Enter the value of A --->");
                        a = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter the value of B --->");
                        b = Convert.ToInt32(Console.ReadLine());
                        result = a - b;
                        Console.WriteLine("Subtration of A and B --->" + result);
                        break;

                    case 3:
                        Console.WriteLine("Enter the value of A --->");
                        a = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter the value of B --->");
                        b = Convert.ToInt32(Console.ReadLine());
                        result = a * b;
                        Console.WriteLine("Multiplication of A and B --->" + result);
                        break;

                    case 4:
                        Console.WriteLine("Enter the value of A --->");
                        a = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter the value of B --->");
                        b = Convert.ToInt32(Console.ReadLine());
                        result = a / b;
                        Console.WriteLine("Devision of A and B --->" + result);
                        break;

                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }
                Console.ReadKey();
               
            
        }
    }
}
