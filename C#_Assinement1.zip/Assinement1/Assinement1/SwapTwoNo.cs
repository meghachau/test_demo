﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assinement1
{

    class SwapTwoNo
    {
        public static void swapno(ref int num1, ref int num2)
        {
            int temp;
            temp = num1;
            num1 = num2;
            num2 = num1;
            Console.WriteLine("After Swapping num1" + num1 + "num2" + num2);
        }

        public static void Main()
        {
           
            Console.WriteLine("Enter 1 number ---> ");
            int number1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2 number ---> ");
            int number2 = Convert.ToInt32(Console.ReadLine());
            swapno(ref number1, ref number2);

        }

    }
}
