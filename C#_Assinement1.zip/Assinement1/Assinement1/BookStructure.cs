﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assinement1
{
    struct book
    {
       public  int bookId;
       public string bookType;
       public string title;
       public int price;

    }
    class BookStructure
    {
        public static void Main()
        {
            int nobook = 3;
            book[] books = new book[nobook];

            for (int i = 1; i < 4; i++)
            {
                Console.WriteLine("Insert inforamtion of book"+ i);
                Console.WriteLine("Enter the book id-->");
                books[i].bookId=Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the book Type-->" );
                books[i].bookType = Console.ReadLine();
                Console.WriteLine("Enter the book Title-->" );
                books[i].title = Console.ReadLine();
                Console.WriteLine("Enter the book price-->");
                books[i].price = Convert.ToInt32(Console.ReadLine());
            }
            Console.ReadKey();


        }
    }
}
