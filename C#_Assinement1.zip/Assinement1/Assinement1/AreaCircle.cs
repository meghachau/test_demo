﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assinement1
{
    class AreaCircle
    {
        const float PI = 3.1415927F;
       // double radius;
        public void AreaCirum(double radius)
        {
            double area = PI * radius * radius;
            Console.WriteLine("Area = {0:F2}", area);
            double circumference = 2 * PI * radius;
            Console.WriteLine("Circumference = {0:F2}", circumference);
        }
       public static void Main()
        { 
            Console.WriteLine("Enter radius of the circle : ");
            double  radius = Convert.ToDouble(Console.ReadLine());
            AreaCircle A = new AreaCircle();
            A.AreaCirum(radius);
            Console.ReadKey();
        }

    

    }
}
